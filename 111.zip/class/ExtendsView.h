//
//  ExtendsView.h
//  derucci-v6
//
//  Created by mac on 13-8-26.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ExtendsView : UIImageView{
    int current;
    NSMutableArray *animationImage;
}
@end
