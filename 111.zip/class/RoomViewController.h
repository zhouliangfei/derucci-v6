//
//  RoomViewController.h
//  derucci-v6
//
//  Created by mac on 13-8-19.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RoomViewController : UIViewController
@property(nonatomic,retain) NSMutableDictionary *source;
@end
